package ru.wexside.misc;

import ru.wexside.misc.ThemePalette;

public final class BuiltInThemes {
    public static final ThemePalette themePalette = new ThemePalette("dark", "Dark", -15724010, -15328992, -14933975, -14473165, -14012355, -15460579, -14670544, -14999769, -13617340, -13024687, -14341323, -12168864, -723206, -4669236, -8024162, -9866366, -11511449, -8626945, 863788287, -41613, -1728053248, -13354169, -14341581, -12498344, -13880514, -871362026, -723206, -8024162, -4669236, 0x66000000, true, true);
    public static final ThemePalette themePalette2 = new ThemePalette("light", "Light", -657672, -1, -1446671, -1972757, -2564635, -460293, -1775378, -1183500, -3090721, -4406064, -2235671, -5392443, -15263200, -12498860, -9208437, -7169370, -5393218, -9679361, 862735871, -1947809, 0x55000000, -2762014, -2038550, -3682600, -2630428, -419430401, -15263200, -9208437, -12498860, 0x22000000, true, true);

    private BuiltInThemes() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}


package ru.wexside.event;

import ru.wexside.event.CancellableEvent;
import ru.wexside.event.Event;

public class MovementSlowdownEvent
extends CancellableEvent
implements Event {
}


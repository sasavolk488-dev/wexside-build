package ru.wexside.misc;

public record ThemePalette(String id, String name, int backgroundPrimary, int backgroundSecondary, int backgroundControl, int backgroundHover, int controlFill, int panelBackground, int formatSelectorFill, int formatFieldFill, int borderPrimary, int borderSubtle, int borderSoft, int borderStrong, int textPrimary, int textSecondary, int textMuted, int textPlaceholder, int textDisabled, int accent, int accentTint, int danger, int modalScrim, int separator, int visualizerSlot, int notificationOutline, int avatarPlaceholder, int hudBackground, int hudTextPrimary, int hudTextMuted, int hudTextSecondary, int hudVignette, boolean blur, boolean hudBlur) {
}

